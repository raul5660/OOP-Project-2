//Created by Charles Miller 4/13/16
public class InvalidWildCardException extends Exception {
	
	 public InvalidWildCardException(String message) {
	        super(message);
	        new ErrorGui(message).setVisible(true);
	    }
}
